 <?php

   $footer_back_top_button  =  aai_option('footer_back_top_button');

   if (!$footer_back_top_button) {
      return;
   }
   ?>

 <!-- Back To Top -->
 <div class="back-to-top">
    <a href="#"><i class="fal fa-arrow-up"></i></a>
 </div>
 <!-- Back To Top -->