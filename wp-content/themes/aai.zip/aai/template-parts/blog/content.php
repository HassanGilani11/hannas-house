
<article <?php post_class(); ?>>
   <?php get_template_part( 'template-parts/blog/format/content', get_post_format() ); ?>       
</article>